package org.affirmio.affirmio;

public class Launcher {
    public static void main(String[] args)
    {
        HelloApplication.main(args);
    }
}
